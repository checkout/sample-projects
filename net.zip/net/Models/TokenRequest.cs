﻿namespace CheckoutSample.Models
{
    public class TokenRequest
    {
        public string? Token { get; set; }
    }
}
