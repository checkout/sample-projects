# Node JS SDK example

# :rocket: Install dependencies

```bash
npm i
```

# :rocket: Run project

```bash
npm start
```

> This will run the project on localhost:4242
